package com.example.remup.data.hilt
import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class Remup: Application()