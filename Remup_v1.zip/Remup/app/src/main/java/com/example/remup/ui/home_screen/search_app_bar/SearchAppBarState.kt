package com.example.remup.ui.home_screen.search_app_bar

enum class SearchAppBarState {
    OPENED,
    CLOSED
}